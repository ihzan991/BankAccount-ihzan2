const BankAccount = require('./BankAccount');
const { Produk, ProdukElektronik } = require('./Produk');

console.log('=== Soal 1: BankAccount ===');
const rekening = new BankAccount('Andi', 500000);
console.log('Saldo awal:', rekening.getSaldo());
console.log('Deposit Rp100.000:', rekening.deposit(100000));
console.log('Saldo setelah deposit:', rekening.getSaldo());
console.log('Withdraw Rp200.000:', rekening.withdraw(200000));
console.log('Saldo setelah withdraw:', rekening.getSaldo());
console.log('Withdraw Rp1.000.000 (ditolak):', rekening.withdraw(1000000));
console.log('Deposit Rp0 (ditolak):', rekening.deposit(0));
console.log('Saldo akhir:', rekening.getSaldo());

console.log('\n=== Soal 2: Produk & ProdukElektronik ===');
const produkBiasa = new Produk('Buku', 50000);
const laptop = new ProdukElektronik('Laptop', 'Rp10.000.000', 2);
console.log(produkBiasa.getInfo());
console.log(laptop.getInfo());
