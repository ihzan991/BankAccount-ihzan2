// Soal 2: Pewarisan (Inheritance) & Override
class Produk {
  constructor(nama, harga) {
    this.nama = nama;
    this.harga = harga;
  }

  getInfo() {
    return `Produk: ${this.nama}, Harga: ${this.harga}`;
  }
}

class ProdukElektronik extends Produk {
  constructor(nama, harga, garansiTahun) {
    super(nama, harga);
    this.garansiTahun = garansiTahun;
  }

  getInfo() {
    return `${super.getInfo()}, Garansi: ${this.garansiTahun} tahun`;
  }
}

module.exports = { Produk, ProdukElektronik };
