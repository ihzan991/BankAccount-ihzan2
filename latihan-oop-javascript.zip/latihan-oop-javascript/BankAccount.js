// Soal 1: Dasar Kelas & Enkapsulasi (Akun Bank)
class BankAccount {
  #saldo;

  constructor(namaPemilik, saldoAwal) {
    this.namaPemilik = namaPemilik;
    this.#saldo = saldoAwal > 0 ? saldoAwal : 0;
  }

  deposit(jumlah) {
    if (jumlah > 0) {
      this.#saldo += jumlah;
      return true;
    }
    return false;
  }

  withdraw(jumlah) {
    if (jumlah > 0 && this.#saldo >= jumlah) {
      this.#saldo -= jumlah;
      return true;
    }
    return false;
  }

  getSaldo() {
    return this.#saldo;
  }
}

module.exports = BankAccount;
